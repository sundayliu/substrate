#!/bin/bash
CYCC_APT_VERSION=$(./version.sh) cycc -i2.0 -s -p MobileSafety.mm
